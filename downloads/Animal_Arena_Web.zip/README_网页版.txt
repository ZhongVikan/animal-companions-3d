动物派对 · Web Demo

请先完整解压。在解压目录打开终端，运行以下命令。

  Windows       py -3 start_web.py
  macOS / Linux python3 start_web.py

启动器会打开本机浏览器。运行需要 Python 3 和支持 WebGL 2 的浏览器。
在手机上试玩时，可将 index.html 和同目录的所有 index.* 文件一并部署到静态 HTTPS 站点后横屏打开。服务器应以 application/wasm 提供 index.wasm。

电脑支持 1–4 名本地键盘玩家。P1 用 WASD 移动，F 投掷，空格格挡。
手机默认为 1 名玩家对战 3 名 AI。左手拖动摇杆，右手投掷或按住格挡。

Godot 4.7.2 Web 单线程构建。微信小游戏使用另行适配的运行环境和打包流程。
